﻿    public class Sign_Up
    {
    public string SignUp(User user)
    {
        using (var context = new StepShopDbContext())
        {
            context.Users.Add(user);
            context.SaveChanges();
            return "Qeydiyyat tamamlandı!";
        }
    }

}

