﻿using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;
public class StepShopDbContext : DbContext
{
    public DbSet<User> Users { get; set; }
    public DbSet<Products> Products { get; set; }


    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
    {
        optionsBuilder.UseSqlServer("Data Source=DESKTOP-D38H9GT;Initial Catalog=Academia;Integrated Security=True;Connect Timeout=30;Encrypt=True;Trust Server Certificate=True;Application Intent=ReadWrite;Multi Subnet Failover=False");
    }
}