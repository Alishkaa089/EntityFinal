﻿public class Invoice
{
        public int Id { get; set; }
        public List<Order> Orders { get; set; } // Siparişlərin siyahısı
        public int CustomerId { get; set; } // Müştərinin ID-si
        public int CashierId { get; set; } // Sifarişləri qeyd edən Cashier-in ID-si
        public DateTime Date { get; set; } // Sipariş vaxtı

        public Invoice()
        {
            Orders = new List<Order>(); 
        }


}

