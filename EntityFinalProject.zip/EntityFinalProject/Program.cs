﻿using System;
using System.Linq;

class Program
{
    static void Main(string[] args)
    {
        {
            using (var context = new StepShopDbContext())
            {
                while (true)
                {
                    Console.WriteLine("\n1. Giriş");
                    Console.WriteLine("2. Qeydiyyat");
                    Console.WriteLine("0. Çıxış");
                    Console.Write("Seçiminizi daxil edin (0, 1 və ya 2): ");
                    string choice = Console.ReadLine();

                    if (choice == "0")
                    {
                        Console.WriteLine("Proqramdan çıxılır...");
                        break;
                    }

                    if (choice == "2")
                    {
                        Console.Write("Yeni istifadəçi adı: ");
                        string newUsername = Console.ReadLine();
                        Console.Write("Yeni şifrə: ");
                        string newPassword = Console.ReadLine();
                        Console.Write("Rol (admin, user, cashier): ");
                        string role = Console.ReadLine().ToLower();

                        if (context.Users.Any(u => u.Username == newUsername))
                        {
                            Console.WriteLine("Bu istifadəçi adı artıq mövcuddur!");
                            continue;
                        }

                        var newUser = new User
                        {
                            Username = newUsername,
                            Password = newPassword,
                            Role = role
                        };

                        context.Users.Add(newUser);
                        context.SaveChanges();
                        Console.WriteLine("Qeydiyyat uğurla tamamlandı! İndi giriş edə bilərsiniz.\n");
                        continue; // geri menyuya qayıtsın
                    }

                    if (choice == "1")
                    {
                        Console.Write("İstifadəçi adı: ");
                        string username = Console.ReadLine();
                        Console.Write("Şifrə: ");
                        string password = Console.ReadLine();

                        var user = context.Users.FirstOrDefault(u => u.Username == username && u.Password == password);
                        if (user == null)
                        {
                            Console.WriteLine("Giriş uğursuz oldu! İstifadəçi tapılmadı.");
                            continue;
                        }

                        Console.WriteLine($"\nGiriş uğurlu oldu! Rolunuz: {user.Role}");
                        switch (user.Role.ToLower())
                        {
                            case "admin":
                                AdminActions(context);
                                break;
                            case "user":
                                UserActions(context, user);
                                break;
                            case "cashier":
                                CashierActions(context);
                                break;
                            default:
                                Console.WriteLine("Tanınmayan rol!");
                                break;
                        }
                    }
                    else
                    {
                        Console.WriteLine("Yanlış seçim!");
                    }
                }
            }
        }


    }

    static void AdminActions(StepShopDbContext context)
    {
        while (true)
        {
            Console.WriteLine("\nAdmin əməliyyatları:");
            Console.WriteLine("1. İstifadəçiləri göstər");
            Console.WriteLine("2. İstifadəçi sil");
            Console.WriteLine("3. Məhsul əlavə et");
            Console.WriteLine("4. Məhsul yenilə");
            Console.WriteLine("5. Məhsul sil");
            Console.WriteLine("6. Məhsulları göstər");
            Console.WriteLine("0. Çıxış");
            Console.Write("Seçiminiz: ");
            string choice = Console.ReadLine();

            switch (choice)
            {
                case "1":
                    var users = context.Users.ToList();
                    Console.WriteLine("\nİstifadəçilər:");
                    foreach (var user in users)
                    {
                        Console.WriteLine($"Id: {user.Id}, İstifadəçi adı: {user.Username}, Rol: {user.Role}");
                    }
                    break;
                case "2":
                    Console.Write("Silinəcək istifadəçinin Id-ni daxil edin: ");
                    int userId = int.Parse(Console.ReadLine());
                    var userToDelete = context.Users.Find(userId);
                    if (userToDelete != null)
                    {
                        context.Users.Remove(userToDelete);
                        context.SaveChanges();
                        Console.WriteLine("İstifadəçi silindi!");
                    }
                    else
                    {
                        Console.WriteLine("İstifadəçi tapılmadı!");
                    }
                    break;
                case "3":
                    Console.Write("Məhsulun adını daxil edin: ");
                    string productName = Console.ReadLine();
                    var newProduct = new Products { Name = productName };
                    context.Products.Add(newProduct);
                    context.SaveChanges();
                    Console.WriteLine("Məhsul əlavə edildi!");
                    break;
                case "4":
                    Console.Write("Yeniləmək istədiyiniz məhsulun Id-ni daxil edin: ");
                    int productId = int.Parse(Console.ReadLine());
                    var productToUpdate = context.Products.Find(productId);
                    if (productToUpdate != null)
                    {
                        Console.Write("Yeni ad daxil edin: ");
                        productToUpdate.Name = Console.ReadLine();
                        context.SaveChanges();
                        Console.WriteLine("Məhsul yeniləndi!");
                    }
                    else
                    {
                        Console.WriteLine("Məhsul tapılmadı!");
                    }
                    break;
                case "5":
                    Console.Write("Silinəcək məhsulun Id-ni daxil edin: ");
                    int deleteId = int.Parse(Console.ReadLine());
                    var productToDelete = context.Products.Find(deleteId);
                    if (productToDelete != null)
                    {
                        context.Products.Remove(productToDelete);
                        context.SaveChanges();
                        Console.WriteLine("Məhsul silindi!");
                    }
                    else
                    {
                        Console.WriteLine("Məhsul tapılmadı!");
                    }
                    break;
                case "6":
                    var products = context.Products.ToList();
                    Console.WriteLine("\nMəhsullar:");
                    foreach (var product in products)
                    {
                        Console.WriteLine($"Id: {product.Id}, Ad: {product.Name}");
                    }
                    break;
                case "0":
                    return;
                default:
                    Console.WriteLine("Yanlış seçim!");
                    break;
            }
        }
    }

    static void UserActions(StepShopDbContext context, User user)
    {
        var basket = new List<Products>();
        while (true)
        {
            Console.WriteLine("\nUser əməliyyatları:");
            Console.WriteLine("1. Məhsulları göstər");
            Console.WriteLine("2. Məhsul əlavə et (sifariş)");
            Console.WriteLine("3. Sebete bax");
            Console.WriteLine("4. Sebetdən məhsul sil");
            Console.WriteLine("5. Alış-verişi tamamla");
            Console.WriteLine("0. Çıxış");
            Console.Write("Seçiminiz: ");
            string choice = Console.ReadLine();

            switch (choice)
            {
                case "1":
                    var products = context.Products.ToList();
                    Console.WriteLine("\nMəhsullar:");
                    foreach (var product in products)
                    {
                        Console.WriteLine($"Id: {product.Id}, Ad: {product.Name}");
                    }
                    break;
                case "2":
                    Console.Write("Sifariş etmək istədiyiniz məhsulun Id-ni daxil edin: ");
                    int productId = int.Parse(Console.ReadLine());
                    var productToAdd = context.Products.Find(productId);
                    if (productToAdd != null)
                    {
                        basket.Add(productToAdd);
                        Console.WriteLine("Məhsul səbətə əlavə edildi!");
                    }
                    else
                    {
                        Console.WriteLine("Məhsul tapılmadı!");
                    }
                    break;
                case "3":
                    Console.WriteLine("\nSəbətiniz:");
                    foreach (var item in basket)
                    {
                        Console.WriteLine($"Id: {item.Id}, Ad: {item.Name}");
                    }
                    break;
                case "4":
                    Console.Write("Səbətdən silmək istədiyiniz məhsulun Id-ni daxil edin: ");
                    int removeId = int.Parse(Console.ReadLine());
                    var productToRemove = basket.FirstOrDefault(p => p.Id == removeId);
                    if (productToRemove != null)
                    {
                        basket.Remove(productToRemove);
                        Console.WriteLine("Məhsul səbətdən silindi!");
                    }
                    else
                    {
                        Console.WriteLine("Məhsul səbətdə tapılmadı!");
                    }
                    break;
                case "5":
                    Console.WriteLine("Alış-veriş tamamlandı! Səbətiniz boşaldıldı.");
                    basket.Clear();
                    break;
                case "0":
                    return;
                default:
                    Console.WriteLine("Yanlış seçim!");
                    break;
            }
        }
    }

    static void CashierActions(StepShopDbContext context)
    {
        while (true)
        {
            Console.WriteLine("\nCashier əməliyyatları:");
            Console.WriteLine("1. Məhsulları göstər");
            Console.WriteLine("2. Sifarişləri göstər");
            Console.WriteLine("0. Çıxış");
            Console.Write("Seçiminiz: ");
            string choice = Console.ReadLine();

            switch (choice)
            {
                case "1":
                    var products = context.Products.ToList();
                    Console.WriteLine("\nMəhsullar:");
                    foreach (var product in products)
                    {
                        Console.WriteLine($"Id: {product.Id}, Ad: {product.Name}");
                    }
                    break;
                case "2":
                    Console.WriteLine("Sifarişlər hələlik daxil edilməyib."); 
                    break;
                case "0":
                    return;
                default:
                    Console.WriteLine("Yanlış seçim!");
                    break;
            }
        }
    }
}
